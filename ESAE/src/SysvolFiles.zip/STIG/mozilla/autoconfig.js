//Place file at C:\Program Files (x86)\Mozilla Firefox\defaults\pref

pref("general.config.filename", "mozilla.cfg");
pref("general.config.obscure_value", 0); // use this to disable the byte-shift
